#include <iostream>
using namespace std; 
int main(){
    cout << "Program started" << endl;
    int n;
    cout<<"enter the number of elements: ";
    cin>>n;
    int arr[n];
    for(int i=0;i<n;i++){
        cout<<"enter the array elemnts: "; 
        cin>>arr[i];
    }
    int hash[100]={0};
    for(int i=0;i<n;i++){
        hash[arr[i]]+=1;
    }
    int q;
    cout<<"enter the total nuuumbers you want to find frequency for:  ";
    cin>>q;
    while(q--){
        int no;
        cout<<"enter the numbers: ";
        cin>>no;
        cout<<hash[no]<<endl;
    }
}








character hashing


#include <iostream>
using namespace std; 
int main(){
    string s;
    cin >> s;
    int hash[26]={0};
    for(int i=0;i<s.size();i++){
        hash[s[i]-'a']++;
    }
    int q;
    cin>> q;
    while(q--){
        char c;
        cin>> c;
        cout<<hash[c-'a']<<endl;
    }
}




for uppercase do c-'A' and if need all character with special one do 265






map




#include <bits/stdc++.h>
using namespace std;
int main(){
    int n;
    cin>>n;
    int arr[n];
    for(int i=0;i<n;i++){
        cin>>arr[i];
    }
    map<int,int>mpp;
    for(int i =0;i<n;i++){
        mpp[arr[i]]++;
    }
    int q;
    cin>>q;
    while(q--){
        int number;
        cin>>number;
        cout<<"output is: ";
        cout<<mpp[number]<<endl;
    }
}


unordered map
write unordered_map insted of map




