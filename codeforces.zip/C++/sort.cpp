
/*selection sort
---------------------------

#include <bits/stdc++.h>
using namespace std;
void selectionsort(int arr[],int n){
    for(int i=0;i<=n-2;i++){
        int mini=i;
        for(int j=i+1;j<=n-1;j++){
            if(arr[j]<arr[mini]){
                mini=j;
            }
        }
        swap(arr[mini],arr[i]);

    }
}
int main(){
    int n;
    cin>>n;
    int arr[n];
    for(int i=0;i<n;i++) cin>>arr[i];
    selectionsort(arr,n);
    for(int j=0;j<n;j++) cout<<arr[j]<<" ";
}*/





//bubble sorting

// #include <bits/stdc++.h>
// using namespace std;
// void bubblesort(int arr[],int n){
//     for(int i=n-1;i>=0;i++){
//         int didswap=0;
//         for(int j=0;j<=i-1;j++){
//             if(arr[j]>arr[j+1]){
//                 int temp=arr[j+1];
//                 arr[j+1]=arr[j];
//                 arr[j]=temp;
//                 didswap++;
//             }
//         }
//         if(didswap==0){
//             break;
//         }
//     }
// }
// int main(){
//     int n;
//     cin>>n;
//     int arr[n];
//     for(int i=0;i<n;i++) cin>>arr[i];
//     bubblesort(arr,n);
//     for(int j=0;j<n;j++){
//         cout<<arr[j]<<" ";
//     }

// }








//insertion sort

#include <bits/stdc++.h>
using namespace std;
int main(){

}