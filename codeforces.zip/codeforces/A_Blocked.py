t = int(input())
for _ in range(t):
    n = int(input())
    a = list(map(int, input().split()))
    
    if len(a) != len(set(a)):
        print(-1)
    else:
        a.sort(reverse=True)
        print(*a)