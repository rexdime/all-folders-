t=int(input())
for i in range(t):
    x=int(input())
    print(67 if x==67 else x+1)