#include <stdio.h>
int main(){

printf("hellow world\n");
char a ="36";
printf("%c",a);
}