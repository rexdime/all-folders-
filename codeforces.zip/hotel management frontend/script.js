// Appointment validation
document.getElementById("appointmentForm").addEventListener("submit", function (e) {
    e.preventDefault();

    const name = document.getElementById("patientName").value.trim();
    const phone = document.getElementById("phone").value.trim();
    const date = document.getElementById("appointmentDate").value;

    const today = new Date().toISOString().split("T")[0];

    if (name === "") {
        alert("Please enter the patient name.");
        return;
    }

    if (!/^[0-9]{10}$/.test(phone)) {
        alert("Please enter a valid 10-digit phone number.");
        return;
    }

    if (date === "" || date < today) {
        alert("Please select today or a future appointment date.");
        return;
    }

    alert("Appointment booked successfully!");
    this.reset();
});


// Live doctor search
document.getElementById("doctorSearch").addEventListener("input", function () {
    const value = this.value.toLowerCase();
    const rows = document.querySelectorAll("#doctorTable tbody tr");

    rows.forEach(function (row) {
        row.style.display =
            row.textContent.toLowerCase().includes(value)
            ? ""
            : "none";
    });
});