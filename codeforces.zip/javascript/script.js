const mycheckbox=document.getElementById("checkbox");
const visa=document.getElementById("visa");
const mastercard=document.getElementById("MASTERCARD");
const paypal=document.getElementById("PAYPAL");
const submit=document.getElementById("submit");
const h1=document.getElementById("h1");
const h2=document.getElementById("h2");

submit.onclick=function(){
    if(mycheckbox.checked){
        h1.textContent="you are subscribed";
    }
    else{
        h1.textContent="you are not subscribed";
    }
    if(mastercard.checked){
        h2.textContent="you have selected master card as a payment option";
    }
    else if(visa.checked){
        h2.textContent="you have selected visa card as a payment option";
    }
    else if(paypal.checked){
        h2.textContent="you have selected paypal as a payment option";
    }
}









const min =1;
const max=100;
const answer= Math.floor(Math.random()*(max - min+1))+min;
console.log(answer); 
let attempts=0;
let guess;
let running =true;
while(running){
    guess=window.prompt(`guess a number between ${min} - ${max}`);
    guess=Number(guess);
    if(isNaN(guess)){
        window.alert("please enter a valid number");

    }
    else if(guess<min||guess>max){
        window.alert("please enter the number in a valid range");
    }
    else{
       attempts++;
       if (guess<answer){
        window.alert("too low");
       }
       else if(answer<guess){
        window.alert("too high");
       }
    }
    
        window.alert(`correct answer was ${answer} and it took you ${attempts}` );
    running =false; 
// }    






const textbox= document.getElementById("textbox");
const fahrenheit=document.getElementById("toFahrenheit");
const celcius=document.getElementById("toCelsius");
const result=document.getElementById("result");
let temp;
function convert(){
    if(fahrenheit.checked){
      temp= Number(textbox.value);
      temp= (temp*9/5)+32;
      result.textContent= temp.toFixed(1)+"°F"
    }
    else if(celcius.checked){
      temp= Number(textbox.value);
      temp= (temp*5/9)-32;
      result.textContent= temp.toFixed(1)+"°C";
    }
    else{
        result.textContent="select a unit";
    }
}





const textbox = document.getElementById("textbox");
const fahrenheit = document.getElementById("toFahrenheit");
const celsius = document.getElementById("toCelsius");
const result = document.getElementById("result");

let temp;

function convert() {
    if (fahrenheit.checked) {
        temp = Number(textbox.value);
        temp = (temp * 9 / 5) + 32;
        result.textContent = temp.toFixed(1) + " °F";
    }
    else if (celsius.checked) {
        temp = Number(textbox.value);
        temp = (temp - 32) * 5 / 9;
        result.textContent = temp.toFixed(1) + " °C";
    }
    else {
        result.textContent = "Select a unit";
    }
}
let fruits=["apple","banana","watermelon"];
let division=[...fruits];
console.log(division); 

function getdog(){
    fetch(`https://dog.ceo/api/breeds/image/random`)
    .then(res=>res.json())
    .then(data=>{
        document.getElementById("dog").src=data.message;
    });
}