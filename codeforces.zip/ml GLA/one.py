# a = int(input("Enter the amount you want: "))


# f = a // 100
# rem100 = a % 100

# e = rem100 // 50
# rem50 = rem100 % 50

# d = rem50 // 10
# rem10 = rem50 % 10

# c = rem10 // 5
# rem5 = rem10 % 5

# b = rem5 // 2
# rem2 = rem5 % 2


# one = rem2 // 1

# no_of_notes = f + e + d + c + b + one

# print("--- Notes Breakdown ---")
# print("100s:", f)
# print("50s:", e)
# print("10s:", d)
# print("5s:", c)
# print("2s:", b)
# print("1s:", one)
# print("Total number of notes:", no_of_notes)






# a = input("enter the number: ")
# sum = 0
# while len(a) > 1:
#     sum = 0
#     c = len(a)
#     a = int(a)
#     for i in range(c):
#         sum = sum + a % 10
#         a = a // 10
#     a = str(sum)   
# print(sum)







# a=int(input("enter the number"))

# count=0
# for i in range(a-2):
#     if a%1==0:
#         print("not prime")
#         break
    
# else:
#      print(" prime")
    








#print the first 100 prime number
# count = 0
# num = 2
# while count < 100:
#     factor = 0
#     for i in range(1, num + 1):
#         if num % i == 0:
#             factor += 1
#     if factor == 2:   
#         print(num, end=" ")
#         count += 1
#     num += 1
# count =0
# num =2
# while count<100:
#     for i in ange(2,int(num)):
#         if num%10==0:
#          break
#     else:
#        print(num,end=" ")
#        count+=1
# #        num+=1
    
# def analyze_list(lst):
#     # assume list is not empty
#     smallest = lst[0]
#     largest = lst[0]
#     total = 0

#     for i in lst:
#         if i < smallest:
#             smallest = i
#         if i > largest:
#             largest = i
#         total += i

#     avg = total / len(lst)

#     # store in dictionary
#     result = {}
#     result["min"] = smallest
#     result["max"] = largest
#     result["avg"] = avg

#     return result


# # taking input
# lst = list(map(int, input("Enter numbers: ").split()))

# output = analyze_list(lst)

# print(output)

a=input("enter the string")
result=""
for ch in a:
    if "a"<=ch<="z":
        result+=chr(ord(ch)-32)
    else:
        result+=ch