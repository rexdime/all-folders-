# Mini Compiler / Arithmetic Expression Evaluator (C)

This project implements a small arithmetic expression pipeline:
- Read expression(s) from stdin or file
- Tokenize to numbers, operators, and parentheses
- Convert infix → postfix (Shunting Yard)
- Evaluate postfix via a stack
- Report syntax errors (invalid symbols, mismatched parentheses)

Goals
- Learn tokenization, stacks, algorithm implementation, and error handling in C
- Practice modular design with headers and source files

Project structure
- src/: C sources (main + modules)
- include/: headers with public types and function prototypes
- docs/REFERENCE.md: syntax patterns and algorithm notes you can copy into your code
- tests/: test plan and sample expressions
- bin/: build output

Build and run (once code is implemented)
- make
- .\bin\mini_compiler.exe (on Windows) or ./bin/mini_compiler (on Unix)

Key modules (functions only; implementations left as TODOs)
- tokenize(const char* input, Token** out, size_t* count)
- infixToPostfix(const Token* in, size_t n, Token** out, size_t* m)
- evaluatePostfix(const Token* postfix, size_t m, double* result)
- checkSyntax(const Token* tokens, size_t n)

Workflow
1) Tokenize input string to Token array
2) Optional checkSyntax pass (unmatched parentheses, invalid sequence)
3) Convert to postfix via Shunting Yard
4) Evaluate postfix stack to a double result

Next steps
- Read docs/REFERENCE.md for syntax templates and algorithm guidance
- Fill in include/*.h and src/*.c stubs with implementations
- Use tests/TEST_PLAN.md to verify behavior