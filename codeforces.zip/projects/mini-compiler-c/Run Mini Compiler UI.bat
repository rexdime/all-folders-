@echo off
setlocal
cd /d "%~dp0"

REM Ensure bin exists
if not exist "bin" mkdir "bin"

REM Build C executable if missing
if not exist "bin\mini_compiler.exe" (
  echo Building C executable...
  gcc -Wall -Wextra -Wpedantic -std=c11 -Iinclude -o bin\mini_compiler.exe src\main.c src\tokenizer.c src\shunting_yard.c src\evaluator.c src\syntax.c
)

REM Install npm dependencies if missing
if not exist "node_modules" (
  echo Installing npm dependencies...
  npm install --no-audit --no-fund
)

REM Start the server minimized
start "" /min node server.js

REM Give the server a moment to start
timeout /t 1 >NUL

REM Open the web UI
start "" http://localhost:3000

endlocal
