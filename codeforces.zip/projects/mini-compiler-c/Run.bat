@echo off
cd /d "%~dp0"
node -v >NUL 2>&1
if errorlevel 1 (
  echo Node.js is required. Please install Node.js and re-run this script.
  pause
  exit /b 1
)

echo Starting Mini Compiler UI...
call "Run Mini Compiler UI.bat"
