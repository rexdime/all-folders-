# Syntax and algorithm reference (copy/paste friendly)

Sections
- Tokens and types (struct/enum)
- Dynamic array with malloc/realloc/free
- Stack implementations (array and linked list)
- Shunting Yard (infix → postfix)
- Postfix evaluation
- Error checking (invalid char, mismatched parens)
- File I/O (fopen, fgets, fseek)
- Syntax snippets: struct, fseek, realloc

Tokens and types
```c
// token types
typedef enum {
    TOK_NUMBER,
    TOK_OPERATOR,   // + - * /
    TOK_LPAREN,     // (
    TOK_RPAREN      // )
} TokenType;

// operator metadata
typedef struct {
    char op;            // '+', '-', '*', '/'
    int precedence;     // 1 for +-, 2 for */
    int right_assoc;    // 0 for left, 1 for right (not used for basic ops)
} OpInfo;

// token
typedef struct {
    TokenType type;
    double number;  // valid if type == TOK_NUMBER
    char op;        // valid if type == TOK_OPERATOR
} Token;
```

Dynamic array of tokens
```c
Token* tokens = NULL;
size_t count = 0, cap = 0;

void push_token(Token t) {
    if (count == cap) {
        size_t new_cap = cap == 0 ? 16 : cap * 2;
        Token* tmp = realloc(tokens, new_cap * sizeof(Token));
        if (!tmp) {
            // handle allocation failure
            perror("realloc");
            exit(1);
        }
        tokens = tmp;
        cap = new_cap;
    }
    tokens[count++] = t;
}

// cleanup
free(tokens);
```

Array-based stack (generic pattern)
```c
typedef struct {
    Token* data;
    size_t top;   // count of items
    size_t cap;
} TokenStack;

void st_init(TokenStack* s) { s->data = NULL; s->top = 0; s->cap = 0; }
int  st_empty(const TokenStack* s) { return s->top == 0; }

void st_push(TokenStack* s, Token v) {
    if (s->top == s->cap) {
        size_t new_cap = s->cap ? s->cap * 2 : 16;
        s->data = realloc(s->data, new_cap * sizeof(Token));
        if (!s->data) { perror("realloc"); exit(1); }
        s->cap = new_cap;
    }
    s->data[s->top++] = v;
}

Token st_pop(TokenStack* s) { return s->data[--s->top]; }
Token st_peek(const TokenStack* s) { return s->data[s->top - 1]; }

void st_free(TokenStack* s) { free(s->data); }
```

Linked-list stack (alternative)
```c
typedef struct Node {
    double value;
    struct Node* next;
} Node;

void push(Node** head, double v) {
    Node* n = malloc(sizeof(*n));
    n->value = v; n->next = *head; *head = n;
}

double pop(Node** head) {
    Node* n = *head; double v = n->value; *head = n->next; free(n); return v;
}
```

Operator helpers
```c
OpInfo op_info(char c) {
    OpInfo i = {c, 0, 0};
    if (c == '+' || c == '-') i.precedence = 1;
    else if (c == '*' || c == '/') i.precedence = 2;
    return i;
}
```

Shunting Yard outline
```c
// Input: tokens[] of length n (numbers, operators, parens)
// Output: postfix[]
void infixToPostfix(const Token* in, size_t n, Token** out, size_t* m) {
    Token* outv = NULL; size_t outc = 0, outcap = 0;
    TokenStack ops; st_init(&ops);

    for (size_t i = 0; i < n; ++i) {
        Token t = in[i];
        if (t.type == TOK_NUMBER) {
            // append to output
        } else if (t.type == TOK_OPERATOR) {
            // while stack not empty and top is operator with higher/equal precedence: pop to output
            // then push current operator
        } else if (t.type == TOK_LPAREN) {
            // push to op stack
        } else if (t.type == TOK_RPAREN) {
            // pop until LPAREN; if none found => mismatched
        }
    }
    // pop remaining operators; error if any parenthesis remains
    // set *out=outv, *m=outc
}
```

Postfix evaluation outline
```c
// Input: postfix tokens
int evaluatePostfix(const Token* p, size_t m, double* result) {
    double* st = NULL; size_t top = 0, cap = 0; // stack of doubles
    for (size_t i = 0; i < m; ++i) {
        if (p[i].type == TOK_NUMBER) {
            // push number
        } else if (p[i].type == TOK_OPERATOR) {
            // pop rhs, pop lhs, apply, push result; underflow => syntax error
        }
    }
    // final stack size must be 1
    // *result = st[0]
    // free stack
    return 0; // 0 on success, non-zero on error
}
```

Error checking ideas
- Invalid character in tokenizer => error token or immediate failure
- Mismatched parentheses => track count; in Shunting Yard ensure LPAREN exists for each RPAREN
- Operator/operand sequence validation (e.g., two numbers in a row without operator) in checkSyntax

File I/O examples
```c
FILE* in = fopen("input.txt", "r");
FILE* out = fopen("output.txt", "w");
char buf[256];
while (fgets(buf, sizeof buf, in)) {
    // process line
    fprintf(out, "%s\n", buf);
}
fclose(in); fclose(out);
```

fseek example
```c
FILE* f = fopen("file.txt", "rb");
fseek(f, 0, SEEK_END);
long size = ftell(f);
fseek(f, 0, SEEK_SET);
// read size bytes if needed
fclose(f);
```

realloc pattern
```c
size_t cap = 0, n = 0; int* a = NULL;
void grow() {
    size_t new_cap = cap ? cap * 2 : 8;
    int* tmp = realloc(a, new_cap * sizeof *a);
    if (!tmp) { /* handle */ }
    a = tmp; cap = new_cap;
}
```

Struct syntax refresher
```c
typedef struct {
    int x; double y;
} Point;

Point p = { .x = 1, .y = 2.0 };
```

Design tips
- Keep Token and TokenType in a header (include/tokenizer.h)
- Expose only function prototypes in headers; keep implementations in src/
- Return error codes (int) and use out-parameters for results
- Free all dynamic memory owned by a function or document ownership semantics
- Keep I/O separate from core logic so you can unit test tokenizer and algorithms easily
