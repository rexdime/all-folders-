#ifndef EVALUATOR_H
#define EVALUATOR_H

#include <stddef.h>
#include "tokenizer.h"

// Evaluate a postfix token stream. Returns 0 on success, non-zero on error.
int evaluatePostfix(const Token* postfix, size_t m, double* result);

#endif // EVALUATOR_H
