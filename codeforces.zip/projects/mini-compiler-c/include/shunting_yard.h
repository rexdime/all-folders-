#ifndef SHUNTING_YARD_H
#define SHUNTING_YARD_H

#include <stddef.h>
#include "tokenizer.h"

// Convert infix token stream to postfix using the Shunting Yard algorithm.
// Returns 0 on success and sets *out (malloc'd) and *m (length). Caller frees *out.
int infixToPostfix(const Token* in, size_t n, Token** out, size_t* m);

#endif // SHUNTING_YARD_H
