#ifndef SYNTAX_H
#define SYNTAX_H

#include <stddef.h>
#include "tokenizer.h"

// Basic syntax validation on the token stream (optional pre-check)
// Returns 0 if OK, non-zero otherwise.
int checkSyntax(const Token* tokens, size_t n);

#endif // SYNTAX_H
