#ifndef TOKENIZER_H
#define TOKENIZER_H

#include <stddef.h>

typedef enum {
    TOK_NUMBER,
    TOK_OPERATOR,
    TOK_LPAREN,
    TOK_RPAREN
} TokenType;

typedef struct {
    TokenType type;
    double number;  // valid if type == TOK_NUMBER
    char op;        // valid if type == TOK_OPERATOR
} Token;

// Tokenize a null-terminated expression string.
// On success: returns 0 and sets *out to a malloc'd array of Token and *count to its length.
// Caller must free(*out).
int tokenize(const char* input, Token** out, size_t* count);

#endif // TOKENIZER_H
