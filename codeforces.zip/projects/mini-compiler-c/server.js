const express = require('express');
const path = require('path');
const fs = require('fs');
const { spawn } = require('child_process');

const app = express();
const PORT = process.env.PORT || 3000;

app.use(express.static(path.join(__dirname, 'public')));
app.use(express.json());

const exePath = path.join(__dirname, 'bin', process.platform === 'win32' ? 'mini_compiler.exe' : 'mini_compiler');

function buildIfMissing() {
  return new Promise((resolve, reject) => {
    fs.access(exePath, fs.constants.X_OK, (err) => {
      if (!err) return resolve(true);
      // Try to build with gcc
      const args = ['-Wall','-Wextra','-Wpedantic','-std=c11','-Iinclude','-o', exePath,
        'src/main.c','src/tokenizer.c','src/shunting_yard.c','src/evaluator.c','src/syntax.c'];
      const proc = spawn('gcc', args, { cwd: __dirname, shell: false });
      let stderr = '';
      proc.stderr.on('data', d => { stderr += d.toString(); });
      proc.on('close', (code) => {
        if (code === 0) return resolve(true);
        reject(new Error('Build failed: ' + stderr));
      });
    });
  });
}

app.post('/run', async (req, res) => {
  const expr = (req.body && req.body.expr || '').toString();
  if (!expr.trim()) return res.status(400).json({ ok: false, error: 'Expression is required' });

  try {
    await buildIfMissing();
  } catch (e) {
    return res.status(500).json({ ok: false, error: e.message });
  }

  const proc = spawn(exePath, [expr], { cwd: __dirname, shell: false });
  let out = '', err = '';
  proc.stdout.on('data', d => { out += d.toString(); });
  proc.stderr.on('data', d => { err += d.toString(); });
  proc.on('close', (code) => {
    if (code === 0) {
      return res.json({ ok: true, result: out.trim() });
    }
    // send stderr or stdout as error message
    const msg = (err || out || 'Execution failed').trim();
    res.status(400).json({ ok: false, error: msg });
  });
});

app.listen(PORT, () => {
  console.log(`mini-compiler UI running on http://localhost:${PORT}`);
});
