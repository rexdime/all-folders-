#include "evaluator.h"
#include <stdlib.h>
#include <stdio.h>

int evaluatePostfix(const Token* postfix, size_t m, double* result) {
    if(!postfix||!result) return 1;
    double* st=NULL; size_t top=0, cap=0;
    
    for(size_t i=0;i<m;++i){
        Token t=postfix[i];
        if(t.type==TOK_NUMBER){
            if(top==cap){ size_t nc=cap?cap*2:16; double* tmp=realloc(st, nc*sizeof(double)); if(!tmp){ perror("realloc"); exit(1);} st=tmp; cap=nc; }
            st[top++] = t.number;
        } else if(t.type==TOK_OPERATOR){
            if(top<2){ free(st); return 1; }
            double rhs=st[--top];
            double lhs=st[--top];
            double v=0.0;
            switch(t.op){
                case '+': v=lhs+rhs; break;
                case '-': v=lhs-rhs; break;
                case '*': v=lhs*rhs; break;
                case '/': if(rhs==0.0){ free(st); return 2; } v=lhs/rhs; break;
                default: free(st); return 1;
            }
            if(top==cap){ size_t nc=cap?cap*2:16; double* tmp=realloc(st, nc*sizeof(double)); if(!tmp){ perror("realloc"); exit(1);} st=tmp; cap=nc; }
            st[top++] = v;
        } else {
            // shouldn't appear in postfix
            free(st); return 1;
        }
    }
    if(top!=1){ free(st); return 1; }
    *result=st[0];
    free(st);
    return 0;
}
