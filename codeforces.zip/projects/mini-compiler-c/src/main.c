// main.c: entry point
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#include "tokenizer.h"
#include "shunting_yard.h"
#include "evaluator.h"
#include "syntax.h"

static char* join_args(int argc, char** argv){
    size_t len=0; for(int i=1;i<argc;++i){ len += strlen(argv[i]) + 1; }
    char* s = (char*)malloc(len+1); if(!s) return NULL; s[0]='\0';
    for(int i=1;i<argc;++i){ strcat(s, argv[i]); if(i<argc-1) strcat(s, " "); }
    return s;
}

int main(int argc, char** argv) {
    char* input_owned = NULL;
    const char* expr = NULL;
    if (argc > 1) {
        input_owned = join_args(argc, argv);
        expr = input_owned;
    } else {
        static char buf[1024];
        if (!fgets(buf, sizeof buf, stdin)) {
            // default sample if no stdin provided
            expr = "3 + 4 * 2 / ( 1 - 5 )";
        } else {
            expr = buf;
        }
    }

    Token* tokens = NULL; size_t n = 0;
    if (tokenize(expr, &tokens, &n) != 0) {
        fprintf(stderr, "tokenize failed\n");
        free(input_owned);
        return 1;
    }

    if (checkSyntax(tokens, n) != 0) {
        fprintf(stderr, "syntax error\n");
        free(tokens); free(input_owned);
        return 1;
    }

    Token* postfix = NULL; size_t m = 0;
    if (infixToPostfix(tokens, n, &postfix, &m) != 0) {
        fprintf(stderr, "infixToPostfix failed\n");
        free(tokens); free(input_owned);
        return 1;
    }

    double result = 0.0;
    if (evaluatePostfix(postfix, m, &result) != 0) {
        fprintf(stderr, "evaluatePostfix failed\n");
        free(tokens); free(postfix); free(input_owned);
        return 1;
    }

    printf("%g\n", result);

    free(tokens);
    free(postfix);
    free(input_owned);
    return 0;
}
