#include "shunting_yard.h"
#include <stdlib.h>
#include <stdio.h>

typedef struct { Token* data; size_t top; size_t cap; } TokStack;
static void st_init(TokStack* s){ s->data=NULL; s->top=0; s->cap=0; }
static int st_empty(const TokStack* s){ return s->top==0; }
static void st_push(TokStack* s, Token v){
    if (s->top==s->cap){ size_t nc=s->cap? s->cap*2:16; Token* t=realloc(s->data, nc*sizeof(Token)); if(!t){perror("realloc"); exit(1);} s->data=t; s->cap=nc; }
    s->data[s->top++]=v;
}
static Token st_pop(TokStack* s){ return s->data[--s->top]; }
static Token st_peek(const TokStack* s){ return s->data[s->top-1]; }

static int precedence(char op){ return (op=='+'||op=='-')?1: (op=='*'||op=='/')?2: -1; }

static void push_out(Token** arr,size_t* cnt,size_t* cap, Token t){
    if(*cnt==*cap){ size_t nc=*cap? *cap*2:16; Token* tmp=realloc(*arr, nc*sizeof(Token)); if(!tmp){perror("realloc"); exit(1);} *arr=tmp; *cap=nc; }
    (*arr)[(*cnt)++]=t;
}

int infixToPostfix(const Token* in, size_t n, Token** out, size_t* m) {
    if(!in||!out||!m) return 1;
    *out=NULL; *m=0;

    Token* outv=NULL; size_t outc=0, outcap=0;
    TokStack ops; st_init(&ops);

    for(size_t i=0;i<n;++i){
        Token t=in[i];
        if(t.type==TOK_NUMBER){
            push_out(&outv,&outc,&outcap,t);
        } else if(t.type==TOK_OPERATOR){
            int p=precedence(t.op);
            while(!st_empty(&ops)){
                Token top=st_peek(&ops);
                if(top.type==TOK_OPERATOR && precedence(top.op)>=p){
                    push_out(&outv,&outc,&outcap, st_pop(&ops));
                } else break;
            }
            st_push(&ops,t);
        } else if(t.type==TOK_LPAREN){
            st_push(&ops,t);
        } else if(t.type==TOK_RPAREN){
            int matched=0;
            while(!st_empty(&ops)){
                Token top=st_pop(&ops);
                if(top.type==TOK_LPAREN){ matched=1; break; }
                push_out(&outv,&outc,&outcap, top);
            }
            if(!matched){ free(outv); free(ops.data); return 1; }
        }
    }

    while(!st_empty(&ops)){
        Token top=st_pop(&ops);
        if(top.type==TOK_LPAREN || top.type==TOK_RPAREN){ free(outv); free(ops.data); return 1; }
        push_out(&outv,&outc,&outcap, top);
    }

    free(ops.data);
    *out=outv; *m=outc;
    return 0;
}
