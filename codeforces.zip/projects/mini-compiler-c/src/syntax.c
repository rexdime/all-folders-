#include "syntax.h"
#include <stdio.h>

// Minimal syntax validation: parentheses balance and basic token order

int checkSyntax(const Token* tokens, size_t n) {
    if(!tokens && n!=0) return 1;
    size_t depth=0;
    enum {EXPECT_OPERAND, EXPECT_OPERATOR} expect = EXPECT_OPERAND;
    for(size_t i=0;i<n;++i){
        Token t=tokens[i];
        if(expect==EXPECT_OPERAND){
            if(t.type==TOK_NUMBER){ expect = EXPECT_OPERATOR; }
            else if(t.type==TOK_LPAREN){ depth++; /* still expect operand */ }
            else return 1;
        } else { // EXPECT_OPERATOR
            if(t.type==TOK_OPERATOR){ expect = EXPECT_OPERAND; }
            else if(t.type==TOK_RPAREN){ if(depth==0) return 1; depth--; /* still EXPECT_OPERATOR */ }
            else return 1;
        }
    }
    if(depth!=0) return 1;
    if(expect!=EXPECT_OPERATOR) return 1; // expression cannot end with operator
    return 0;
}
