#include "tokenizer.h"
#include <ctype.h>
#include <stdlib.h>
#include <string.h>
#include <stdio.h>

// tokenizer.c: simple tokenizer for numbers, + - * / and parentheses

static void push_token_dynamic(Token** arr, size_t* count, size_t* cap, Token t) {
    if (*count == *cap) {
        size_t new_cap = *cap ? (*cap * 2) : 16;
        Token* tmp = (Token*)realloc(*arr, new_cap * sizeof(Token));
        if (!tmp) { perror("realloc"); exit(1); }
        *arr = tmp; *cap = new_cap;
    }
    (*arr)[(*count)++] = t;
}

int tokenize(const char* input, Token** out, size_t* count) {
    if (!input || !out || !count) return 1;
    *out = NULL; *count = 0;

    Token* arr = NULL; size_t n = 0, cap = 0;
    const char* p = input;
    while (*p) {
        unsigned char c = (unsigned char)*p;
        if (isspace(c)) { ++p; continue; }

        if (isdigit(c) || c == '.') {
            char* end = NULL;
            double val = strtod(p, &end);
            if (end == p) { free(arr); return 1; }
            Token t = {0};
            t.type = TOK_NUMBER;
            t.number = val;
            push_token_dynamic(&arr, &n, &cap, t);
            p = end;
            continue;
        }

        if (c == '+' || c == '-' || c == '*' || c == '/') {
            Token t = {0};
            t.type = TOK_OPERATOR;
            t.op = (char)c;
            push_token_dynamic(&arr, &n, &cap, t);
            ++p;
            continue;
        }

        if (c == '(') {
            Token t = {0}; t.type = TOK_LPAREN; push_token_dynamic(&arr, &n, &cap, t);
            ++p; continue;
        }
        if (c == ')') {
            Token t = {0}; t.type = TOK_RPAREN; push_token_dynamic(&arr, &n, &cap, t);
            ++p; continue;
        }

        // invalid character
        free(arr);
        return 1;
    }

    *out = arr;
    *count = n;
    return 0;
}
