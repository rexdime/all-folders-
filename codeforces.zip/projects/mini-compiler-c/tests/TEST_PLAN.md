# Test plan

Execute each expression and verify result and error behavior.

Basic arithmetic
- 1+2 => 3
- 2*3+4 => 10
- 2*(3+4) => 14
- (2+3)*4 => 20
- 3+4*2/(1-5) => 1

Edge cases
- 42 => 42
- 3/2 => 1.5
- 10/(5-5) => error (division by zero)
- ((1+2) => syntax error (mismatch)
- 2++2 => syntax error
- a+1 => invalid character error

Whitespace and formatting
- "   7   +   8 " => 15
- "(  1 +  (2*3) )" => 7

File I/O
- Read from tests/samples.txt and write results to tests/results.txt

Notes
- Use a tolerance for floating-point comparisons when needed (e.g., 0.0001)
