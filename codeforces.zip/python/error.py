class BookAlredyBorrowedError(Exception):
    pass
class BookNotBorrowedError(Exception):
    pass

class book:
    isborrowed=False
    def __init__(self,title,author,isbn):
        self.title=title
        self.author=author
        self.isbn=isbn
    def __str__(self):
        return f"{self.title} by {self.author}"

    def borrowed(self):
        if self.isborrowed:
            raise BookAlredyBorrowedError(f"{self.title} by {self.author} is alredy borrowed")
        self.isborrowed=True

    def return_book(self):
        if self.isborrowed:
            raise  BookNotBorrowedError(f"{self.title} by {self.author} was not borrowed")
        self.isborrowed=False

b=book("1984","orwell","123")
b.borrowed()
print(b.isborrowed)
class InvalidGradeError(Exception):
    pass

# class Student:
#     def __init__(self, name, roll_no):
#         self.name = name
#         self.roll_no = roll_no
#         self.grades = []

#     def __str__(self):
#         return f"{self.name} (Roll No: {self.roll_no})"

#     def add_grade(self, grade):
#         if not (0 <= grade <= 100):          # check BEFORE appending
#             raise InvalidGradeError(f"{grade} is not a valid grade (0-100)")
#         self.grades.append(grade)

# s = Student("Aditya", 5)
# s.add_grade(85)
# s.add_grade(150)   # should raise InvalidGradeError