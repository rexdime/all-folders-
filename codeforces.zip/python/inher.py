from main import employee
class developer(employee):
    raise_amt=1.10
    def apply_raise(self):
        return super().apply_raise()
    def __init__(self,first,last,pay,prog_language):
         super().__init__(first,last,pay)
         self.prog_language=prog_language

dev1=developer("jack","joul",5000,"python")
dev1.apply_raise()
 