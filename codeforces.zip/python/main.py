class employee:
    raise_amt=1.04
    def __init__(self,first,last,pay):
        self.first=first
        self.last=last
        self.pay=pay
        self.email=first +'.'+last +"@company.com"

    def __str__(self):
        return self.first+" "+self.last
    def apply_raise(self):
        self.pay = self.pay*self.raise_amt


  
emp1=employee("aditya","sirohi",50000)
emp2=employee("test","user",60000)
emp1.apply_raise()
print(emp1.pay)
