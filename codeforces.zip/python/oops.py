# class Book:
#      max_discount=50
#      def __init__(self,title,author,price):
#           self.title=title
#           self.author=author
#           self.price=price
#      def apply_discount(self,percent):
#           if percent>=0 and percent<=self.max_discount:
#                self.price-= (self.price*percent)/100
#           else:
#                raise ValueError("invalid discount")
#      def __str__(self):
#           return f"{self.title} by {self.author} price = {self.price}"

# book1=Book("x","y",5000)
# try:
#     book1.apply_discount(60)
#     print(book1)
# except ValueError as e:
#  print(e)

     



class movie:
    def __init__(self,title,director,actors):
        self.title=title
        self.director=director
        self.actors=actors
        self.reviews=[]

    def add_reviews( self,author,rating,comments=""):
        if not(1<= rating<=5):
            raise ValueError("rating must be between 1 and 5")
        self.reviews.append(review)
        return self.reviews
