# class Dataset:
#     count=0
#     def __init__(self,name,rows,columns):
#         self.name=name
#         self.rows=rows
#         self.columns=columns
#         Dataset.count+=1

#     def summary(self):
#         print(f"{self.name}: {self.rows} X {self.columns}")
#     @classmethod
#     def from_csv_path(cls,path):
#         name,dims=path.split('_')
#         rows,columns=dims.replace('.csv','').split('x')
#         return cls(name,int(rows),int(columns) )

# d1=Dataset("sales",100,5)
# d2=Dataset("user",200,4)
# d3=Dataset.from_csv_path("sales_1000x5.csv")
# d1.summary()
# d3.summary()
# print(Dataset.count)



# class BankAccount:
#     def __init__(self,name,balance):
#         self.name=name
#         self.balance=balance
        

#     def deposit(self,amount):
#         self.last_deposit=amount
#         self.balance+=amount
#         return self.last_deposit
    
#     def withdraw(self,amount):
#         self.last_withdraw=amount
#         self.balance-=amount
#         return self.last_withdraw
#     @staticmethod
#     def is_valid_amount(amount):
#         if amount>0:
#             print("amount is valid")
#         else:
#             print("ammount is invalid")

#     def __str__(self):
#         return f"name:{self.name}\nbalance:{self.balance}"
# b1=BankAccount("aditya",100)
# b1.deposit(200)
# BankAccount.is_valid_amount(-10)
# print(b1)







# -----------------ENCAPTULATION--------------------


class Temperature:
    pass