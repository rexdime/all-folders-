# Take a string from user and count vowels without using any built-in function
# Reverse a string without using any built-in function
# Check if a string is palindrome
# Count occurrences of each character in a string
# Remove all spaces from a string without using built-in functions
for ch in a:
lst2+=i