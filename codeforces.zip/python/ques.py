#reverse a number
# n=int(int(input("enter the number: ")))
# reverse=0
# while n>0:
#     digit=n%10
#     reverse=reverse*10+digit
#     n=n//10
     
# print("the reverse of the number is:",reverse)





# largest digit
# n=int(input("enter the number: "))
# largest=0
# while n>0:
#     digit=n%10
#     if digit>largest:
#         largest=digit
#     n=n//10


# print("the largest number is",largest)




# palindrome number
# n=int(input("enter the number: "))
# original=n
# reverse=0
# while n>0:
#     digit=n%10
#     reverse=reverse*10+digit
#     n=n//10
# if original==reverse:
#     print("it is palindrome")
# else:
#     print("it is not palindrome")





# armstrong number
# n=int(input("enter the number: "))
# original=n
# sum=0
# count=len(str(n))
# while n>0:
#     digit=n%10
#     sum+=digit**count
#     n=n//10
# if sum==original:
#     print("it is an armstrong number")
# else:
#     print("it is not")





#prime number or not
# n=int(input("enter the number"))
# count=0
# for i in range(1,n+1):
#     if n%i==0:
#         count+=1
# if count==2:
#     print("prime")
# else:
#     print("not prime")




# fibonacchi series
# n=int(input("enter the number"))
# a=0
# b=1
# print(a)
# print(b)

# for i in range(2,n):
#     c=a+b
#     print(c)
#     a=b
#     b=c





# count even digits
# n=int(input("enter the number"))
# count=0
# while n>0:
#     digit=n%10
#     if digit%2==0:
#         count+=1
#     n=n//10
# print(count)






# swap first and last digit
# num = int(input("Enter number: "))
# original = num
# last = num % 10
# first = num
# count = 0
# while first >= 10:
    # first = first // 10
    # count += 1
# middle = original % (10**count)
# middle = middle // 10
# new_num = last*(10**count) + middle*10 + first
# print("New number:", new_num)


# s = input()
# old = input("replace: ")
# new = input("with: ")

# result = ""

# for ch in s:
#     if ch == old:
#         result += new
#     else:
#         result += ch

# print(result)






      


#index safeguard
# def analyze_list(lst):
#     # assume list is not empty
#     smallest = lst[0]
#     largest = lst[0]
#     total = 0

#     for i in lst:
#         if i < smallest:
#             smallest = i
#         if i > largest:
#             largest = i
#         total += i

#     avg = total / len(lst)

#     # store in dictionary
#     result = {}
#     result["min"] = smallest
#     result["max"] = largest
#     result["avg"] = avg

#     return result


# # taking input
# lst = list(map(int, input("Enter numbers: ").split()))

# output = analyze_list(lst)

# print(output)
# disctionary product lookup
# def get_product(n):
#     products = {}
#     for ch in range(n):..........................................................................................
#         key = input("Enter key: ")
#         value = input("Enter value: ")
#         products[key] = value

#     print(products)

#     item = input("Enter product name: ")

#     try:
#         price = products[item]
#         print("Price of", item, "is:", price)
    
#     except KeyError:
#         print("Product Unavailable")
# n = int(input("Enter number of items: "))
# get_product(n)
# a=input("enter the string")
# result=""
# for ch in a:  
#     if "A"<=ch<="Z":
#         result+=chr(ord(ch)+32)
#     else:
#         result+=ch
# print(result)
# a=input("enter the string")
# result=""
# for ch in a:
#     if ch!=" ":
#         result+=ch
#     else:
#      continue
# print(result)
# a=input("enter the string")
# result=""
# count=0
# for ch in a:
#     if ch in "aeiouAEIOU":
#         count+=1
#         result+=ch
#     else:
#         continue
# print("the no of vowels are: ",count,"the no vowels in a sentance are: ",result)
# s = input("Enter string: ")
# word = input("Enter word to count: ")

# count = 0
# words = s.split()

# for w in words:
#     if w == word:
#         count += 1

# print("Occurrences:", count)
# lst=list(map(int,input("enter the list with space btw them :").split()))
# count=0
# for i in lst:
#     count+=1
# print(count) new =
# lst=list(map(int,input("enter the list with space btw them :").split()))
# new=[]
# index=int(input("enter the index: "))
# value=int(input("enter the value: "))
# for i in range (0,len(lst)):
#     if i==index:
#         new+=[value]
#     new+=[lst[i]]
# if len(lst)<=index:
#      new+=[value]
# print(new)
# lst=list(map(int,input("enter the list with space btw them :").split()))
# a=int(input("enter the number: "))
# found=False
# for i in range(len(lst)):
#     if lst[i]==a:
#         found=True
# print(found)
# x=tuple(map(int,input("enter the tupleusig spaces").split()))
# b=int(input("enter the number: "))
# count=0
# for i in range(len(x)):
#     if x[i]==b:
#         count+=1
# print("the number occured ",count," times")

# d = {}

# for i in range(1, 6):
#     d[i] = i * i

# # print(d)




# def vowel_count():
#     count=0
#     x=""
#     a=input("enter the string")
#     for ch in a:
#         if ch in "aeiouAEIOU":
#              x+="*"
#              count+=1
#         else:
#             x+=ch
#     print(x," no of vowels in the sentance are: ",count)
# vowel_count()



# try:
#     s = input("Enter string: ")
#     d = {}

#     for i in range(len(s)):
#         ch = s[i]

#         if ch in d:
#             d[ch] = d[ch] + [i]
#         else:
#             d[ch] = [i]

#     print(d)

# except Exception as e:
#     print("Error:", e)

# finally:
#     print("Mapping process complete.")

a=input("enter the string")
d={}
for i in range(len(a)):
    ch=a[i]
    if ch in d:
        d[ch]+=[i]
    else:
        d[ch]=[i]
print(d)