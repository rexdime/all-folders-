# def analyze_list(lst):
#     # assume list is not empty
#     smallest = lst[0]
#     largest = lst[0]
#     total = 0

#     for i in lst:
#         if i < smallest:
#             smallest = i
#         if i > largest:
#             largest = i
#         total += i

#     avg = total / len(lst)

#     # store in dictionary
#     result = {}
#     result["min"] = smallest
#     result["max"] = largest
#     result["avg"] = avg

#     return result


# # taking input
# lst = list(map(int, input("Enter numbers: ").split()))

# output = analyze_list(lst)

# print(output)


# a=input("enter the string")
# b=""
# for ch in a:
#     if "a"<= ch<="z":
#         b+=chr(ord(ch)-32)
     
#     else:
#         b+=ch
# print(b)





# a=input("enter the string")
# b=""
# for ch in a:
#     if ch!=" ":
#         b+=ch
# print(b)






# a=input("enter the string")
# b=""
# count=0
# for ch in a:
#     if ch in "aeiouAEIOU":
#         b+=ch
#         count+=1
# print(b,count)







# a=input("enter the string")
# b=input("enter the word")
# count=0
# for ch in a:
#     if ch==b:
#         count+=1
#     else:
#         continue
# print(count)









# a=input("enter the string")
# b=input("enter the word")
# last=-1
# for i in range (len(a)):
#     if a[i]==b:
#         last=i
# print(last)





# a=list(map(int,input("enter the list using spaces").split()))
# count=0
# for i in a:
#     count+=1
# print(count)





# a=list(map(int,input("enter the list using spaces").split()))
# c=int(input("enter "))
# b=a+[c]
# print(b)




# a=tuple(map(int,input("enter the tuple using spaces").split()))
# x=int(input("enter the element"))
# temp=[0]*(len(a)+1)
# for i in range(len(a)):
#     temp[i]=a[i]
# temp[len(a)]=x
# print(tuple(temp))




# a=list(map(int,input("enter the list using spaces").split()))
# x=int(input("enter the element"))
# index=int(input("enter the index"))
# new=[0]*(len(a)+1)
# for i in range(index):
#     new[i]=a[i]
# new[index]=x
# for j in range(index,len(a)):
#     new[j+1]=a[j]
# print(new)
# print(bool(1))

# def fun():
#     x = list(map(int, input("enter list: ").split()))
#     for i in range(len(x)):
#         if x[i] % 2 == 0:
#             x[i] = x[i] ** 2
#     print(x)

# fun()

# x=10
# def fun():
#     x=5
#     print(x)
# fun()
# import numpy as np
# import pandas as pd



# a=np.zeros((2,3))
# # b=np.ones((2,2))
# # c=np.eye(3)
# # d=np.arange(0,10,2)
# # e=np.linspace(0,1,5)
# print(a)
# def fun():
    
#     x=list(map(int,input("enter the list using spaces: ").split()))
#     a=int(input("enter the element: "))
#     b=int(input("enter the index: "))
#     new=[None]*(len(x)+1)
#     j=0
#     for i in range(len(x)+1):
#         if i==b:
#             new[i]=a
#         else:
#             new[i]=x[j]
#             j+=1
#     print(new)
# fun()





# def fun():
#     x=list(map(int,input("enter the list: ").split()))
#     value=int(input("enter the value: "))
#     new=[None]*(len(x)-1)
#     j=0
#     for i in range(len(x)):
#         if x[i]==value:
#             continue
#         else:
#             new[j]=x[i]
#             j+=1
#     print(new)
# fun()

        

# def fun():
#     x=list(map(int,input("enter the list: ").split()))
#     index=int(input("enter the value: "))
#     new=[None]*(len(x)-1)
#     j=0
#     for i in range(len(x)):
#         if i==index:
#             continue
#         else:
#             new[j]=x[i]
#             j+=1
#     print(new)
# fun()




# d = {"name": "Aditya", "age": 20, "city": "Delhi"}
# value = input("enter value to search: ")
# found = False
# for k in d:
#     if str(d[k]) == value:
#         found = True
#         break
# print("value exists" if found else "value not found")
# def fun():
#     x = input("enter the string use commas to separate elements: ")
#     y = input("enter the string use commas to separate elements: ")
#     lst1 = list(x.split(','))
#     lst2 = list(y.split(','))
#     lst3 = []
#     for i in lst1:
#         found = False
#         for j in lst2:
#             if i.strip() == j.strip():
#                 found = True
#                 break
#         if found == False:
#             lst3 += [i.strip()]
#     print(lst3)

# fun()
# def fun():
#     x=list(map(int,input("enter the keys use spaces").split()))
#     y=list(map(str,input("enter the keys use spaces").split()))
#     values=[]
#     for i in y:
#         try:
#             values+=[int(i)]
#         except:
#             values+=[i]
#     d=dict(zip(x,values))
#     print('original dictionary" ',d)
#     result={}
#     for i in d:
#         value=d[i]
#         if value in result:
#             result[value]+=[i]
#         else:
#             result[value]=[i]
#     print('grouped dict: ',result)
# fun()

 # 4.
# Take a list of numbers from user. Without using any built-in function, 
# separate them into two lists — one for numbers that are perfect squares
#  and one for numbers that are not.
# x=list(map(int,input("enter the lsit use spaces").split()))
# square_list=[]
# lst=[]

# for i in x:
#     sqrt=int(i**0.5)
#     if i==sqrt*sqrt:
#         square_list+=[i]
#     else:
#         lst+=[i]
# print('perfect square are',square_list,'normal number are',lst)
        




# 5.
# Take a sentence from user. Count frequency of each word using a dictionary. 
# Then find the word that appears most frequently.
#  If two words have same frequency store them in a tuple.
# x=list(map(str,input("enter the sentance").split()))
# lst2={}
# index=0
# for i in x:
#      lst2[index]=i
#      index+=1
# result={}
# for i in lst2:
#     value=lst2[i]
#     if value in result:
#       result[value]+=[i]
#     else:
#       result[value]=[i]
# for i in result:
#    x=len(result[i])
#    if
# print(result)
# print(i,"appears",len(result[i]),"times")


# x = list(map(str, input("enter the sentence: ").split()))
# lst2 = {}
# index = 0
# for i in x:
#     lst2[index] = i
#     index += 1

# result = {}
# for i in lst2:
#     value = lst2[i]
#     if value in result:
#         result[value] += [i]
#     else:
#         result[value] = [i]

# # find max frequency
# max_freq = 0
# for k in result:
#     if len(result[k]) > max_freq:
#         max_freq = len(result[k])

# # add words with max frequency to tuple
# t = ()
# for k in result:
#     if len(result[k]) == max_freq:
#         t += (k,)

# print("result dict:", result)
# print("most frequent words:", t)


# 
# 6.
# Take a string "10, abc, 3.5, xyz, 2" — convert valid numbers to a list.
#  Now without using any built-in function find mean of those numbers.
#  If list is empty print "no valid numbers found".
# x = list(map(str, input("enter the sentence: ").split()))
# lst=[]
# lst1=[]
# z=0
# mean=0
# for i in x:
#     try:
#         lst+=[int(i)]
#         z=len(lst)
        

#     except:
#         lst1+=[i]
# if z==0:
#     print("no valid numbers inn the list")
# else:
#     total=0
#     for i in range(z):
#         total+=lst[i]
#     mean=(total)/z
# print(mean)