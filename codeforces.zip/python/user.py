import json

# with open("users.json","r") as json_file:
#     data =json.load(json_file)
# for person in data:
#     print(person['first_name'])

# with open("user,py","w") as f:
#     json.dump(data ,f, indent=2)



# real use of **kwargs


import json


class Person:
    def __init__(self, **kwargs):
        self.data = kwargs

    def display(self):
        print(f"Name: {self.data['first_name']} {self.data['last_name']}")
        print(f"Email: {self.data['email']}")


with open("users.json", "r") as file:
    users = json.load(file)


people = []

for user_data in users:
    person = Person(**user_data)
    people.append(person)


for person in people:
    person.display()

